package Controllore;


import Ticket.Prenotazione;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import static java.lang.Integer.parseInt;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Utente
 */

//classe principale del server
public class Server {

    public static void main(String[] args) throws IOException {
        
        ArrayList listaA = new ArrayList(); //crea lista delle prossime prenotazioni
        Prenotazione prenotazione;
        
        ServerSocket listener = creaSocket(9090); //crea e accetta comunicazioni sul socket
        Socket socket = listener.accept();
        System.out.println("Connesso da IP: " + socket.getLocalSocketAddress() + ", sulla porta: " + socket.getPort());
        
//          ciclo infinito che prende la stringa in arrivo dal totem, crea una istanza di prenotazione (metodo creaPrenotazione)
//          dopo di che grazie al metodo aggiungiPrenotazione la aggiunge alla lista corretta (per ora solo la lista A funziona)
//          sono presenti alcuni print per avere dei feedback sul fatto che stia realmente instanziando e aggiungendo elementi
            while (true) {

                BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String codiceprenotazione = input.readLine();

                prenotazione = creaPrenotazione(codiceprenotazione);

                System.out.println("prenotazione creata " + prenotazione);

                aggiungiPrenotazione(prenotazione, listaA);
            }
        
    }
    
    private static ServerSocket creaSocket(int port) throws IOException{
        
        ServerSocket socket = new ServerSocket(port);
        System.out.println("Creato il Socket");
        return socket;
    }

    private static void aggiungiPrenotazione(Prenotazione prenotazione, ArrayList listaA) {
        
        switch(prenotazione.getType()){
            
            case("A"): 
                listaA.add(prenotazione);
                System.out.println("aggiunta prenotazione di tipo A");
                break;
                
            default:
                System.out.println("Tipologia non riconsciuta");
        
        }
    }

    private static Prenotazione creaPrenotazione(String codiceprenotazione) {
        
        String parts[] = codiceprenotazione.split("_");
        
        Prenotazione temp = new Prenotazione(parseInt(parts[1]), parts[0]);
        
        return temp;
    }
}
