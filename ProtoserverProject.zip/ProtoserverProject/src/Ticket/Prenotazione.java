/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ticket;

/**
 *
 * @author Utente
 */


//classe per la  creazione di prenotazioni (per ora non si fa differenza tra tipologie, ovvero non ci sono classi "figlie")
public class Prenotazione {
    
    int numero;
    String tipologia;
    String codice;
    
    public Prenotazione(int num, String tipo){
        this.numero = num;
        this.tipologia = tipo;
        this.codice = this.tipologia + this.numero;
    }
    
    public String getType(){
        return tipologia;
    }
    
    @Override
    public String toString(){
        return codice;
    }
}
